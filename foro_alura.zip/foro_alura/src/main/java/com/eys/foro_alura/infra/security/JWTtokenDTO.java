package com.eys.foro_alura.infra.security;

public record JWTtokenDTO(String JWTtoken) {
}
