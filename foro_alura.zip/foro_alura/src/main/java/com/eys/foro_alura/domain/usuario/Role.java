package com.eys.foro_alura.domain.usuario;

public enum Role {
    ADMINISTRADOR,
    USUARIO,
    EXPECTADOR
}
