package com.eys.foro_alura.domain.topico.validaciones.actualizar;

import com.eys.foro_alura.domain.topico.ActualizarTopicoDTO;

public interface ValidarTopicoActualizado {

    public void validate(ActualizarTopicoDTO data);

}
