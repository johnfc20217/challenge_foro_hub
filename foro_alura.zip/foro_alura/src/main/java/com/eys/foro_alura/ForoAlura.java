package com.eys.foro_alura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForoAlura {

	public static void main(String[] args) {
		SpringApplication.run(ForoAlura.class, args);
	}

}



