package com.eys.foro_alura.domain.usuario;

public record AutenticacionUsuarioDTO(String username, String password) {
}
