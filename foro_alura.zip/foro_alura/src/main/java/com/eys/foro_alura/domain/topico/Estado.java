package com.eys.foro_alura.domain.topico;

public enum Estado {
    OPEN,
    CLOSED,
    DELETED
}
