package com.eys.foro_alura.domain.curso;

public enum Categoria {
    FRONTEND,
    BACKEND,
    DEVOPS,
    ROBOTICS,
    IA

}
