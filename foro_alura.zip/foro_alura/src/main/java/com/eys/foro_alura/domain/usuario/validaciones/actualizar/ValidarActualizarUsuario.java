package com.eys.foro_alura.domain.usuario.validaciones.actualizar;

import com.eys.foro_alura.domain.usuario.ActualizarUsuarioDTO;

public interface ValidarActualizarUsuario {
    public void validate(ActualizarUsuarioDTO data);
}
