package com.eys.foro_alura.domain.topico.validaciones.crear;

import com.eys.foro_alura.domain.topico.CrearTopicoDTO;

public interface ValidarTopicoCreado {

    public void validate(CrearTopicoDTO data);
}
